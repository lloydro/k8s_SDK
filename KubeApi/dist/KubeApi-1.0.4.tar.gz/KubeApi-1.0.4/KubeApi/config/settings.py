
POD_IP_DELAY = 720 # 获取pod ip的等待时间，单位s
POD_IP_TIMES = 20 # 获取pod ip的次数