# ================ URL配置 ===================
REQUEST_URL = 'http://cloud.ruijie.work:9527'
# REQUEST_URL = 'http://172.30.22.82:8000'


# ================ 定时配置 ===================
POD_IP_DELAY = 1 # 获取pod ip的等待时间，单位s
POD_IP_TIMES = 1 # 获取pod ip的次数